const container = document.querySelector('.container');
const btns = document.querySelectorAll('.btn');
const imgList = ["1","2","3"];

let index = 0;
btns.forEach((button) => {
    button.addEventListener('click', () => {
        if (button.classList.contains('btn-left')) {
            index--;
            if (index < 0) {
                index = imgList.length - 1;
            }
        } else {
            index++;
            if (index === imgList.length) {
                index = 0;
            }
        }
        container.style.background = `url("./assets/images/${imgList[index]}.jpg") center/cover  no-repeat`;
        console.log(index);
    });
});
